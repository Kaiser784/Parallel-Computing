#include<time.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
long long int gcd (long long int a , long long int b);
long long int pollard ( long long int n);
